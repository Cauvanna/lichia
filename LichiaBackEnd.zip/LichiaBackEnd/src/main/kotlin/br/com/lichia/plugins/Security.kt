package br.com.lichia.plugins

import io.ktor.server.application.*

fun Application.configureSecurity() {
}
