rootProject.name = "lichia-ktor"

// Este arquivo configura o nome do projeto.

// Arquivos .kts são do tipo Kotlin Script. Usa sintaxe semelhante ao Kotlin, mas é executado como script ao
// invés de sem compilar como um .kt.
